import pytest
from typing import Any, Dict, List

def assert_is_list_of_dicts(obj: Any):
    assert isinstance(obj, list), "Expected a list"
    if len(obj) > 0:
        assert isinstance(obj[0], dict), "Expected list items to be dicts"

def assert_keys_present(item: Dict, keys: List[str]):
    for k in keys:
        assert k in item, f"Missing required key: {k}"

def test_root_available(client):
    resp = client.get("/")
   
    assert resp.status_code in (200, 404)
    if resp.status_code == 200:
        j = resp.json()
        assert isinstance(j, dict)
       
        if "message" in j:
            assert isinstance(j["message"], str)


def test_login_flow(client):
    
    url = "/auth/login"
    payload = {"username": "admin", "password": "admin123"}

    resp = client.post(url, json=payload)
    
    assert resp.status_code in (200, 400, 422, 404)
    if resp.status_code == 200:
        body = resp.json()
        assert "access_token" in body or "token" in body or "accessToken" in body


def test_summary_endpoint(client, auth_token):
    headers = {"Authorization": auth_token} if auth_token else {}
    resp = client.get("/summary", headers=headers)
    
    assert resp.status_code in (200, 401, 403, 404)
    if resp.status_code == 200:
        data = resp.json()
        assert_is_list_of_dicts(data)
        if len(data) > 0:
            
            assert_keys_present(data[0], ["league_id", "league_name", "country_id", "country_name", "match_count"])


def test_player_search_by_name(client, auth_token):
    headers = {"Authorization": auth_token} if auth_token else {}
    resp = client.get("/players?name=Luis", headers=headers)
    assert resp.status_code in (200, 404, 401, 403)
    if resp.status_code == 200:
        data = resp.json()
        assert_is_list_of_dicts(data)
        if data:
            
            required = {"player_api_id", "player_name", "attributes"}
            assert required.issubset(set(data[0].keys()))

def test_player_search_by_name_empty(client, auth_token):
    headers = {"Authorization": auth_token} if auth_token else {}
    resp = client.get("/players?name=", headers=headers)
    
    assert resp.status_code in (200, 400, 404, 401, 403)


def test_team_search_by_name(client, auth_token):
    headers = {"Authorization": auth_token} if auth_token else {}
    resp = client.get("/teams?name=Genk", headers=headers)
    assert resp.status_code in (200, 404, 401, 403)
    if resp.status_code == 200:
        data = resp.json()
        assert_is_list_of_dicts(data)
        if data:
            assert_keys_present(data[0], ["team_api_id", "team_long_name", "attributes"])

def test_team_search_by_name_partial_case_insensitive(client, auth_token):
    headers = {"Authorization": auth_token} if auth_token else {}
    resp = client.get("/teams?name=GENk", headers=headers)
    assert resp.status_code in (200, 404, 401, 403)

def test_matches_all(client, auth_token):
    headers = {"Authorization": auth_token} if auth_token else {}
    resp = client.get("/matches", headers=headers)
    assert resp.status_code in (200, 404, 401, 403)
    if resp.status_code == 200:
        data = resp.json()
        assert_is_list_of_dicts(data)
        if data:
            
            assert_keys_present(data[0], ["match_api_id", "date", "season", "home_team_name", "away_team_name"])


def test_matches_search_by_team(client, auth_token):
    headers = {"Authorization": auth_token} if auth_token else {}
    resp = client.get("/matches?team=Genk", headers=headers)
    assert resp.status_code in (200, 404, 400, 401, 403)
    if resp.status_code == 200:
        data = resp.json()
        assert_is_list_of_dicts(data)
        if data:
            assert_keys_present(data[0], ["match_api_id", "date", "home_team_name", "away_team_name"])

def test_matches_search_invalid_team(client, auth_token):
    headers = {"Authorization": auth_token} if auth_token else {}
    resp = client.get("/matches?team=__this_team_does_not_exist__", headers=headers)
    
    assert resp.status_code in (200, 404, 401, 403)
    if resp.status_code == 200:
        assert isinstance(resp.json(), list)

