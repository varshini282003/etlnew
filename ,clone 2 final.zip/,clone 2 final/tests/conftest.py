# tests/conftest.py
import os
import pytest
from fastapi.testclient import TestClient
from p3_DataInterface.main import app

@pytest.fixture(scope="module")
def client():
    
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="module")
def auth_token(client):
    
    login_url = "/auth/login"
    # Common default credentials used in many examples. Change if your project uses different ones.
    payload = {"username": "admin", "password": "admin123"}

    try:
        # Try JSON first
        resp = client.post(login_url, json=payload)
    except Exception:
        return None

    if resp.status_code == 200:
        data = resp.json()
        token = data.get("access_token") or data.get("token") or data.get("accessToken")
        if token:
            return f"Bearer {token}"

    # Try form-encoded (some implementations expect form)
    resp2 = client.post(login_url, data=payload)
    if resp2.status_code == 200:
        data = resp2.json()
        token = data.get("access_token") or data.get("token") or data.get("accessToken")
        if token:
            return f"Bearer {token}"

    # Couldn't get a token — return None and let tests adapt
    return None
