const API = "http://127.0.0.1:8000";
let token = localStorage.getItem("token");
let matches = [];
let page = 0;

const headers = () => ({ Authorization: `Bearer ${token}` });

function show(id) {
  for (const d of document.querySelectorAll(".box")) {
    d.classList.add("hidden");
  }
  document.getElementById(id).classList.remove("hidden");
}

document.getElementById("loginBtn").onclick = async () => {
  const u = username.value;
  const p = password.value;

  const res = await fetch(API + "/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ username: u, password: p })
  });

  const data = await res.json();
  if (!res.ok) return loginMsg.innerText = data.detail;

  token = data.access_token;
  localStorage.setItem("token", token);
  loginBox.classList.add("hidden");
  nav.classList.remove("hidden");
  show("players");
};

function logout() {
  token = null;
  localStorage.clear();
  location.reload();
}


async function searchPlayers() {
  const name = playerName.value;
  const res = await fetch(`${API}/players?name=${name}`, { headers: headers() });
  const data = await res.json();

  playerTable.innerHTML = "";
  data.forEach((p,i) => {
    playerTable.innerHTML += `<tr onclick="playerAttrShow(${i})">
      <td>${p.player_api_id}</td><td>${p.player_name}</td>
      <td>${p.height}</td><td>${p.weight}</td></tr>`;
  });

  window.players = data;
}

function playerAttrShow(i) {
  playerAttr.innerHTML = "";
  players[i].attributes.forEach(a => {
    playerAttr.innerHTML += `<tr>
      <td>${a.date}</td><td>${a.overall_rating}</td>
      <td>${a.potential}</td><td>${a.preferred_foot}</td>
      <td>${a.attacking_work_rate}</td><td>${a.defensive_work_rate}</td></tr>`;
  });
}

/* TEAMS */
async function searchTeams() {
  const name = teamName.value;
  const res = await fetch(`${API}/teams?name=${name}`, { headers: headers() });
  const data = await res.json();

  teamTable.innerHTML = "";
  data.forEach((t,i) => {
    teamTable.innerHTML += `<tr onclick="teamAttrShow(${i})">
      <td>${t.team_api_id}</td><td>${t.team_long_name}</td><td>${t.team_short_name}</td></tr>`;
  });

  window.teams = data;
}

function teamAttrShow(i) {
  teamAttr.innerHTML = "";
  teams[i].attributes.forEach(a => {
    teamAttr.innerHTML += `<tr>
      <td>${a.date}</td><td>${a.buildUpPlaySpeed}</td>
      <td>${a.buildUpPlayDribbling}</td><td>${a.buildUpPlayPassing}</td>
      <td>${a.chanceCreationCrossing}</td><td>${a.chanceCreationShooting}</td>
      <td>${a.defencePressure}</td><td>${a.defenceAggression}</td>
      <td>${a.defenceTeamWidth}</td></tr>`;
  });
}

/* MATCHES + PAGINATION */
async function loadMatches() {
  const res = await fetch(API + "/matches/", { headers: headers() });
  matches = await res.json();
  page = 0;
  renderMatches();
}

async function searchMatches() {
  const team = matchTeam.value;
  const res = await fetch(`${API}/matches/search?team=${team}`, { headers: headers() });
  matches = await res.json();
  page = 0;
  renderMatches();
}

function renderMatches() {
  matchTable.innerHTML = "";
  const start = page * 10;
  matches.slice(start, start + 10).forEach(m => {
    matchTable.innerHTML += `<tr>
      <td>${m.date}</td><td>${m.home_team_name}</td>
      <td>${m.away_team_name}</td><td>${m.home_team_goal}-${m.away_team_goal}</td>
      <td>${m.season}</td><td>${m.league_name}</td><td>${m.country_name}</td></tr>`;
  });

  pageInfo.innerText = `Page ${page + 1}`;
}

function nextPage(){ if((page+1)*10 < matches.length){ page++; renderMatches();}}
function prevPage(){ if(page>0){ page--; renderMatches();}}

/* SUMMARY */
async function loadSummary() {
  const s = season.value;
  const res = await fetch(`${API}/summary${s ? "?season="+s : ""}`, { headers: headers() });
  const data = await res.json();

  summaryTable.innerHTML = "";
  data.forEach(r => summaryTable.innerHTML += `<tr>
    <td>${r.league_id}</td><td>${r.league_name}</td>
    <td>${r.country_name}</td><td>${r.match_count}</td></tr>`);
}

if (token) {
  loginBox.classList.add("hidden");
  nav.classList.remove("hidden");
  show("players");
}
