import logging
import os
from datetime import datetime
from typing import Optional

# Module-level cached logger instance
_logger: Optional[logging.Logger] = None


def setup_logger(log_dir: str = "logs", log_file: Optional[str] = None) -> logging.Logger:
    """
    Configure and return a shared application logger.

    - Creates logs directory (relative to project root).
    - Writes logs to a daily file: log_YYYY-MM-DD.log
    - Logs to both file and console.
    - Can be called multiple times, but logger is created only once.
    """

    global _logger

    # If we already created the logger, just return it
    if _logger is not None:
        return _logger

    # Base directory = project root (one level above /common)
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    log_dir_path = os.path.join(base_dir, log_dir)
    os.makedirs(log_dir_path, exist_ok=True)

    # Default log file name: log_YYYY-MM-DD.log
    if log_file is None:
        log_file = f"log_{datetime.now().strftime('%Y-%m-%d')}.log"

    log_path = os.path.join(log_dir_path, log_file)

    # Use a named logger instead of the root logger
    logger = logging.getLogger("soccer_app_logger")
    logger.setLevel(logging.INFO)

    # Avoid adding duplicate handlers if called again
    if logger.handlers:
        return logger

    # File handler
    file_handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    file_formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s"
    )
    file_handler.setFormatter(file_formatter)

    # Console handler
    console_handler = logging.StreamHandler()
    console_formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s"
    )
    console_handler.setFormatter(console_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    logger.info(f"Logger initialized — writing to: {log_path}")

    _logger = logger
    return logger


def get_logger() -> logging.Logger:
    """
    Helper used in other files:
        from common.logger_config import get_logger

    Ensures we always return the same configured logger.
    """
    global _logger
    if _logger is None:
        _logger = setup_logger()
    return _logger
