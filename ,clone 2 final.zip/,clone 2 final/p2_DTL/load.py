import os
import time
import pandas as pd
from typing import Any, Dict, List, Optional
from common.logger_config import setup_logger
from p2_DTL.neo4j_config import Neo4jConnection, get_neo4j_driver, close_neo4j_driver
from neo4j.exceptions import ServiceUnavailable, TransientError

logger = setup_logger()
conn = Neo4jConnection()

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATA_DIR = os.path.normpath(os.path.join(BASE_DIR, "..", "cleaned_data"))

def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    mapping = {c: str(c).strip().lower().replace(" ", "_").replace("-", "_") for c in df.columns}
    df.rename(columns=mapping, inplace=True)
    return df

def read_csv(path: str) -> pd.DataFrame:
    try:
        df = pd.read_csv(path, dtype=str, low_memory=False)
    except Exception:
        df = pd.read_csv(path, dtype=str, low_memory=False, engine="python", on_bad_lines="skip")
    df = normalize_columns(df)
    return df

def _run_batch_with_retries(session, cypher: str, batch: List[Dict[str, Any]], max_retries: int = 3, retry_delay: int = 2) -> bool:

    for retry in range(max_retries):
        try:
            session.run(cypher, rows=batch)  # type: ignore[arg-type]
            return True
        except (ServiceUnavailable, TransientError, BufferError) as e:
            logger.warning(f"Retry {retry+1}/{max_retries} after transient error: {e}")
            time.sleep(retry_delay)
            if retry == max_retries - 1:
                raise
        except Exception as e:
            logger.error(f"Batch failed with non-transient error: {e}")
            return False
    return False

def batch_send(cypher: str, rows: List[Dict[str, Any]], batch_size: int = 500) -> int:
    total = 0
    if not rows:
        return 0
    with conn.driver.session() as session:  # type: ignore
        for i in range(0, len(rows), batch_size):
            batch = rows[i:i + batch_size]
            try:
                success = _run_batch_with_retries(session, cypher, batch)
                if success:
                    total += len(batch)
                    if total % 2000 == 0:
                        logger.info(f"Processed {total} rows so far...")
            except Exception:
                # Log the failure then re-raise to preserve original behavior
                logger.exception("Batch failed after retries, aborting batch_send.")
                raise
            time.sleep(0.02)
    return total

CY_COUNTRY = """
UNWIND $rows AS r 
MERGE (c:Country {id: toInteger(r.id)})
SET c.name = r.name
"""

CY_LEAGUE = """
UNWIND $rows AS r
MERGE (l:League {id: toInteger(r.id)})
SET l.name = r.name
WITH l, r
CALL {
    WITH l, r
    MATCH (c:Country {id: toInteger(r.country_id)})
    MERGE (l)-[:BELONGS_TO_COUNTRY]->(c)
}
"""

CY_TEAM = """
UNWIND $rows AS r
MERGE (t:Team {team_api_id: toInteger(r.team_api_id)})
SET t.team_fifa_api_id = CASE WHEN r.team_fifa_api_id = '' THEN NULL ELSE toInteger(r.team_fifa_api_id) END,
    t.team_long_name = r.team_long_name,
    t.team_short_name = r.team_short_name
"""

CY_TEAM_ATTR = """
UNWIND $rows AS r
WITH r WHERE r.team_api_id <> ''
MERGE (t:Team {team_api_id: toInteger(r.team_api_id)})
MERGE (ta:TeamAttributes {team_api_id: toInteger(r.team_api_id), date: r.date})
SET ta.buildUpPlaySpeed = toInteger(r.buildupplayspeed),
    ta.buildUpPlayDribbling = toInteger(r.buildupplaydribbling),
    ta.buildUpPlayPassing = toInteger(r.buildupplaypassing),
    ta.chanceCreationPassing = toInteger(r.chancecreationpassing),
    ta.chanceCreationCrossing = toInteger(r.chancecreationcrossing),
    ta.chanceCreationShooting = toInteger(r.chancecreationshooting),
    ta.defencePressure = toInteger(r.defencepressure),
    ta.defenceAggression = toInteger(r.defenceaggression),
    ta.defenceTeamWidth = toInteger(r.defenceteamwidth)
MERGE (t)-[:TEAM_HAS_ATTRIBUTES]->(ta)
"""

CY_PLAYER = """
UNWIND $rows AS r
MERGE (p:Player {player_api_id: toInteger(r.player_api_id)})
SET p.player_fifa_api_id = toInteger(r.player_fifa_api_id),
    p.player_name = r.player_name,
    p.birthday = r.birthday,
    p.height = toFloat(r.height),
    p.weight = toFloat(r.weight)
"""

CY_PLAYER_ATTR = """
UNWIND $rows AS r
WITH r WHERE r.player_api_id <> ''
MERGE (p:Player {player_api_id: toInteger(r.player_api_id)})
MERGE (pa:PlayerAttributes {player_api_id: toInteger(r.player_api_id), date: r.date})
SET pa.overall_rating = toInteger(r.overall_rating),
    pa.potential = toInteger(r.potential),
    pa.preferred_foot = r.preferred_foot,
    pa.attacking_work_rate = r.attacking_work_rate,
    pa.defensive_work_rate = r.defensive_work_rate
MERGE (p)-[:PLAYER_HAS_ATTRIBUTES]->(pa)
"""

CY_MATCH = """
UNWIND $rows AS r
WITH r WHERE r.match_api_id <> ''
MERGE (m:Match {match_api_id: toInteger(r.match_api_id)})
SET m.id = toInteger(r.id),
    m.season = r.season,
    m.stage = toInteger(r.stage),
    m.date = r.date,
    m.home_team_goal = toInteger(r.home_team_goal),
    m.away_team_goal = toInteger(r.away_team_goal),
    m.IWD = r.iwd,
    m.IWA = r.iwa
WITH m, r
CALL {
    WITH m, r
    MATCH (c:Country {id: toInteger(r.country_id)})
    MERGE (m)-[:MATCH_IN_COUNTRY]->(c)
}
CALL {
    WITH m, r
    MATCH (l:League {id: toInteger(r.league_id)})
    MERGE (m)-[:MATCH_IN_LEAGUE]->(l)
}
CALL {
    WITH m, r
    MATCH (ht:Team {team_api_id: toInteger(r.home_team_api_id)})
    MERGE (m)-[:HOME_TEAM]->(ht)
}
CALL {
    WITH m, r
    MATCH (at:Team {team_api_id: toInteger(r.away_team_api_id)})
    MERGE (m)-[:AWAY_TEAM]->(at)
}
"""

LOADERS = [
    ("country", CY_COUNTRY),
    ("league", CY_LEAGUE),
    ("team", CY_TEAM),
    ("team_attributes", CY_TEAM_ATTR),
    ("player", CY_PLAYER),
    ("player_attributes", CY_PLAYER_ATTR),
    ("match", CY_MATCH),
]

def process_all():
    logger.info(" Starting data load process...")
    files = [f for f in os.listdir(DATA_DIR) if f.lower().startswith("cleaned_") and f.endswith(".csv")]
    if not files:
        logger.error("No cleaned_*.csv files found in %s", DATA_DIR)
        return

    for name, cypher in LOADERS:
        file = next((f for f in files if name in f.lower()), None)
        if not file:
            logger.warning(f"No file for {name}, skipping.")
            continue

        path = os.path.join(DATA_DIR, file)
        df = read_csv(path)
        logger.info(f" Loading {len(df)} rows from {file}")
        rows = df.replace({pd.NA: None}).to_dict(orient="records")
        total = batch_send(cypher, rows, batch_size=200) # type: ignore
        logger.info(f" Finished {name}: {total} rows processed")

    with conn.driver.session() as session:  # type: ignore
        def count(q): return session.run(q).single().get("c")  # type: ignore
        summary = {
            "Countries": count("MATCH (n:Country) RETURN count(n) AS c"),
            "Leagues": count("MATCH (n:League) RETURN count(n) AS c"),
            "Teams": count("MATCH (n:Team) RETURN count(n) AS c"),
            "Players": count("MATCH (n:Player) RETURN count(n) AS c"),
            "Matches": count("MATCH (n:Match) RETURN count(n) AS c"),
            "HOME_TEAM": count("MATCH ()-[r:HOME_TEAM]->() RETURN count(r) AS c"),
            "AWAY_TEAM": count("MATCH ()-[r:AWAY_TEAM]->() RETURN count(r) AS c"),
        }
        logger.info(f"Validation Summary: {summary}")

    logger.info(" All data successfully loaded into Neo4j!")

if __name__ == "__main__":
    try:
        process_all()
    except KeyboardInterrupt:
        logger.warning("Interrupted manually.")
    except Exception as e:
        logger.exception(f"Fatal error: {e}")
    finally:
        conn.close()
        logger.info(" Neo4j connection closed successfully.")
