import os
import re #dentify patterns dynamically
import pandas as pd
from datetime import datetime
from common.logger_config import setup_logger

logger = setup_logger()

base_dir = os.path.abspath(os.path.dirname(__file__))
input_path = os.path.normpath(os.path.join(base_dir, "..", "data"))
output_path = os.path.normpath(os.path.join(base_dir, "..", "cleaned_data"))
os.makedirs(output_path, exist_ok=True)

ID_PATTERN = re.compile(r"(?:^id$|_id$|api_id$)", flags=re.IGNORECASE)

def should_keep_column(col: str) -> bool:
    return bool(ID_PATTERN.search(col))


def clean_id_columns(df: pd.DataFrame) -> pd.DataFrame:
 
    for col in df.columns:
        if ID_PATTERN.search(col):
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int)
    return df


def build_drop_map(df: pd.DataFrame, filename: str):
    base_name = os.path.splitext(filename)[0].replace("cleaned_", "").replace("Cleaned_", "")
    drop_map = {
        "Country": [],
        "League": [],
        "Team": [],
        "Team_Attributes": [
            "buildUpPlaySpeedClass", "buildUpPlayDribblingClass",
            "buildUpPlayPassingClass", "buildUpPlayPositioningClass",
            "chanceCreationPassingClass", "chanceCreationCrossingClass",
            "chanceCreationShootingClass", "chanceCreationPositioningClass",
            "defencePressureClass", "defenceAggressionClass",
            "defenceTeamWidthClass", "defenceDefenderLineClass"
        ],
        "Player": [],
        "Player_Attributes": [
            "crossing", "finishing", "heading_accuracy", "short_passing", "volleys",
            "dribbling", "curve", "free_kick_accuracy", "long_passing", "ball_control",
            "acceleration", "sprint_speed", "agility", "reactions", "balance",
            "shot_power", "jumping", "stamina", "strength", "long_shots", "aggression",
            "interceptions", "positioning", "vision", "penalties", "marking",
            "standing_tackle", "sliding_tackle", "gk_diving", "gk_handling",
            "gk_kicking", "gk_positioning", "gk_reflexes"
        ],
        "Match": [
            "goal", "shoton", "shotoff", "foulcommit", "card", "cross", "corner", "possession",
            *[f"home_player_X{i}" for i in range(1, 12)],#List Comprehension Line
            *[f"away_player_X{i}" for i in range(1, 12)],
            *[f"home_player_Y{i}" for i in range(1, 12)],
            *[f"away_player_Y{i}" for i in range(1, 12)],
            *[f"home_player_{i}" for i in range(1, 12)],
            *[f"away_player_{i}" for i in range(1, 12)],
        ]
        
    }
    betting_prefixes = ("B365", "BW", "IWH", "LB", "PS", "WH", "SJ", "VC", "GB", "BS")
    drop_cols = drop_map.get(base_name, []).copy()
    drop_cols += [col for col in df.columns if col.startswith(betting_prefixes)]
    final_drop = [col for col in drop_cols if not should_keep_column(col)]
    return final_drop


def process_file(filepath: str, filename: str):
    try:
        df = pd.read_csv(filepath)
        df = clean_id_columns(df)
        drop_cols = build_drop_map(df, filename)
        df = df.drop(columns=drop_cols, errors="ignore").dropna(how="all").drop_duplicates()

        for col in df.columns:
            if "date" in col.lower() or "birthday" in col.lower():
                df[col] = pd.to_datetime(df[col], errors="coerce").dt.date

        if "season" in df.columns:
            valid_seasons = ["2010/2011", "2011/2012", "2012/2013", "2013/2014", "2014/2015", "2015/2016"]
            df = df[df["season"].isin(valid_seasons)]

        cleaned_path = os.path.join(output_path, f"cleaned_{filename}")
        df.to_csv(cleaned_path, index=False)
        logger.info(f" Cleaned {filename} ({len(df)} rows)")
    except Exception as e:
        logger.error(f"Error cleaning {filename}: {e}")


def run():
    for file in os.listdir(input_path):
        if not file.endswith(".csv"):
            continue
        process_file(os.path.join(input_path, file), file)


if __name__ == "__main__":
    logger.info(" Cleaning started...")
    run()
    logger.info(" Cleaning complete.")
