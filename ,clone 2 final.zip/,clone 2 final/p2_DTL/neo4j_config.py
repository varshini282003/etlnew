import os
from typing import Optional
from neo4j import GraphDatabase, Driver
from dotenv import load_dotenv
from common.logger_config import get_logger

logger = get_logger()

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ENV_PATH = os.path.join(BASE_DIR, ".env")

if os.path.exists(ENV_PATH):
    load_dotenv(ENV_PATH)
    logger.info(f".env loaded from: {ENV_PATH}")
else:
    logger.warning(f".env NOT found at: {ENV_PATH}")


_driver: Optional[Driver] = None


def _create_driver() -> Driver:
    
    uri = os.getenv("NEO4J_URI")
    user = os.getenv("NEO4J_USER")
    password = os.getenv("NEO4J_PASSWORD")

    if not all([uri, user, password]):
        logger.error(" Missing Neo4j environment variables!")
        raise ValueError("Missing NEO4J_URI / NEO4J_USER / NEO4J_PASSWORD in .env")

    try:
        logger.info(f"Connecting to Neo4j → {uri}")
        driver = GraphDatabase.driver(uri, auth=(user, password))  # type: ignore[arg-type]
        _test_connection(driver)
        logger.info(" Neo4j connection successful.")
        return driver

    except Exception as e:
        logger.error(f" Could not connect to Neo4j: {e}")
        raise


def _test_connection(driver: Driver):
    """
    INTERNAL: Runs a simple query to ensure DB is reachable.
    """
    try:
        with driver.session() as session:  # type: ignore
            result = session.run("RETURN 'Neo4j OK' AS msg")
            logger.info(f"Neo4j test → {result.single()['msg']}") # type: ignore
    except Exception as e:
        logger.error(f"Neo4j test failed: {e}")
        raise

def get_neo4j_driver() -> Driver:
   
    global _driver

    if _driver is None:
        _driver = _create_driver()

    return _driver


def close_neo4j_driver():
    
    global _driver

    if _driver is not None:
        try:
            _driver.close()
            logger.info(" Neo4j driver closed.")
        except Exception as e:
            logger.error(f"Error closing Neo4j driver: {e}")
        finally:
            _driver = None


def ensure_indexes():
    
    try:
        driver = get_neo4j_driver()
        with driver.session() as session:  # type: ignore
            session.run(
                "CREATE INDEX IF NOT EXISTS FOR (p:Player) ON (p.player_name)"
            )
            session.run(
                "CREATE INDEX IF NOT EXISTS FOR (t:Team) ON (t.team_long_name)"
            )
        logger.info("Indexes ensured.")
    except Exception as e:
        logger.error(f"Failed to create indexes: {e}")

class Neo4jConnection:
    

    def __init__(self):
        self.driver = get_neo4j_driver()

    def verify_connection(self):
        _test_connection(self.driver)

    def get_driver(self) -> Driver:
        return self.driver

    def close(self):
        close_neo4j_driver()
