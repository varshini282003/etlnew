from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from common.logger_config import get_logger
from p2_DTL.neo4j_config import get_neo4j_driver, ensure_indexes, close_neo4j_driver
from p3_DataInterface.routes import auth,player,team,match,summary
from p3_DataInterface.utils.error_handler import global_exception_handler


logger = get_logger()

app = FastAPI(
    title="European Soccer Database API",
    version="2.0",
    description="FastAPI interface for European Soccer Dataset using Neo4j Graph DB"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],        
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



@app.exception_handler(Exception)
async def core_exception_handler(request, exc):
    return await global_exception_handler(request, exc) # type: ignore

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(player.router, prefix="/players", tags=["Players"])
app.include_router(team.router, prefix="/teams", tags=["Teams"])
app.include_router(match.router, prefix="/matches", tags=["Matches"])
app.include_router(summary.router, prefix="/summary", tags=["Summary"])


@app.on_event("startup")
def startup_event():
   
    try:
        get_neo4j_driver()
        logger.info("Neo4j driver initialized at startup.")

        ensure_indexes()
        logger.info("Indexes ensured on startup.")

    except Exception as e:
        logger.error(f"Startup error: {e}")


@app.on_event("shutdown")
def shutdown_event():
    
    try:
        close_neo4j_driver()
        logger.info("Neo4j driver closed cleanly.")
    except Exception as e:
        logger.error(f"Shutdown error: {e}")


@app.get("/")
async def root():
    return {"message": "Welcome to the European Soccer API v2 "}
