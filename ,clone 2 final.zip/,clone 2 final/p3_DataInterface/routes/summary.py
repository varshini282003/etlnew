from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List
import re

from common.logger_config import get_logger
from p2_DTL.neo4j_config import get_neo4j_driver

from p3_DataInterface.schemas.summary_schema import SummaryResponse
from p3_DataInterface.utils.jwt_utils import get_current_user

router = APIRouter()
logger = get_logger()


@router.get("/", response_model=List[SummaryResponse])
async def get_summary(
    season: str = Query(None, description="Season like 2015/2016 (optional)"),
    current_user: dict = Depends(get_current_user)
):
    driver = get_neo4j_driver()

    if season:
        if not re.match(r"^\d{4}/\d{4}$", season):
            raise HTTPException(
                status_code=400,
                detail="Season must be in 'YYYY/YYYY' format"
            )

        cypher = """
        MATCH (m:Match {season: $season})
        MATCH (m)-[:MATCH_IN_LEAGUE]->(l:League)-[:BELONGS_TO_COUNTRY]->(c:Country)
        RETURN l.id AS league_id, l.name AS league_name,
               c.id AS country_id, c.name AS country_name,
               COUNT(m) AS match_count
        ORDER BY match_count DESC
        """
        params = {"season": season}
    else:
        cypher = """
        MATCH (m:Match)
        MATCH (m)-[:MATCH_IN_LEAGUE]->(l:League)-[:BELONGS_TO_COUNTRY]->(c:Country)
        RETURN l.id AS league_id, l.name AS league_name,
               c.id AS country_id, c.name AS country_name,
               COUNT(m) AS match_count
        ORDER BY match_count DESC
        """
        params = {}

    with driver.session() as session:
        result = session.run(cypher, params)
        data = [
            SummaryResponse(
                league_id=record["league_id"],
                league_name=record["league_name"],
                country_id=record["country_id"],
                country_name=record["country_name"],
                match_count=record["match_count"],
            )
            for record in result
        ]

    if not data:
        raise HTTPException(status_code=404, detail="No summary data found")

    return data
