from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List

from common.logger_config import get_logger
from p3_DataInterface.schemas.match_schema import MatchResponse
from p3_DataInterface.services.match_service import (
    fetch_all_matches,
    fetch_matches_by_team
)
from p3_DataInterface.utils.jwt_utils import get_current_user

router = APIRouter(tags=["Matches"])
logger = get_logger()


# -------------------------------------------------------------
# API 1: GET ALL MATCHES (table view)
# -------------------------------------------------------------
@router.get("/", response_model=List[MatchResponse])
def get_all_matches(current_user=Depends(get_current_user)):
    try:
        matches = fetch_all_matches()
        if not matches:
            raise HTTPException(status_code=404, detail="No matches found")
        return matches

    except Exception as e:
        logger.exception(f"Error fetching matches: {e}")
        raise HTTPException(status_code=500, detail="Internal error retrieving matches.")


# -------------------------------------------------------------
# API 2: SEARCH MATCHES BY TEAM NAME
# -------------------------------------------------------------
@router.get("/search", response_model=List[MatchResponse])
def search_matches_by_team(
    team: str = Query(..., description="Team name (partial allowed)"),
    current_user=Depends(get_current_user)
):
    try:
        results = fetch_matches_by_team(team)

        if not results:
            raise HTTPException(
                status_code=404,
                detail=f"No matches found for team name containing '{team}'."
            )

        return results

    except Exception as e:
        logger.exception(f"Error searching matches by team '{team}': {e}")
        raise HTTPException(status_code=500, detail="Internal error while searching matches.")
