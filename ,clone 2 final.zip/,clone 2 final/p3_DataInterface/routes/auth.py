from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm

from common.logger_config import get_logger
from p3_DataInterface.utils.jwt_utils import (
    authenticate_user,
    create_access_token
)
from p3_DataInterface.schemas.auth_schema import Token
from p3_DataInterface.utils.constants import UNAUTHORIZED

router = APIRouter()
logger = get_logger()


@router.post("/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    username = form_data.username
    password = form_data.password

    logger.info(f"Login attempt: {username}")

    user = authenticate_user(username, password)
    if not user:
        logger.warning(f"Invalid login: {username}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=UNAUTHORIZED,
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = create_access_token({"sub": username})
    return Token(access_token=token)
