from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List

from common.logger_config import get_logger
from p2_DTL.neo4j_config import get_neo4j_driver

from p3_DataInterface.services.team_service import get_teams_by_name
from p3_DataInterface.schemas.team_schema import TeamResponse
from p3_DataInterface.utils.jwt_utils import get_current_user
from p3_DataInterface.utils.constants import TEAM_NOT_FOUND

router = APIRouter()
logger = get_logger()


@router.get("/", response_model=List[TeamResponse])
async def search_teams(
    name: str = Query(..., description="Team name (partial / full match)"),
    current_user: dict = Depends(get_current_user)
):
    logger.info(f"Searching teams name ~ {name}")

    driver = get_neo4j_driver()
    teams = get_teams_by_name(driver, name)

    if not teams:
        raise HTTPException(status_code=404, detail=TEAM_NOT_FOUND)

    return teams
