from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List

from common.logger_config import get_logger
from p2_DTL.neo4j_config import get_neo4j_driver

from p3_DataInterface.services.player_service import get_players_by_name
from p3_DataInterface.schemas.player_schema import PlayerResponse
from p3_DataInterface.utils.jwt_utils import get_current_user
from p3_DataInterface.utils.constants import PLAYER_NOT_FOUND

router = APIRouter()
logger = get_logger()


@router.get("/", response_model=List[PlayerResponse])
async def search_players(
    name: str = Query(..., description="Player name (partial search allowed)"),
    current_user: dict = Depends(get_current_user)
):
    logger.info(f"Searching players name ~ {name}")

    driver = get_neo4j_driver()
    players = get_players_by_name(driver, name)

    if not players:
        raise HTTPException(status_code=404, detail=PLAYER_NOT_FOUND)

    return players
