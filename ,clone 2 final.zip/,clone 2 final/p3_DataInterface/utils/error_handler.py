from fastapi import Request
from fastapi.responses import JSONResponse

from common.logger_config import get_logger

logger = get_logger()


def global_exception_handler(request: Request, exc: Exception):
   
    logger.error(f" Unhandled Exception → {exc} | Path: {request.url}")

    return JSONResponse(
        status_code=500,
        content={
            "error": str(exc),
            "path": str(request.url)
        },
    )
