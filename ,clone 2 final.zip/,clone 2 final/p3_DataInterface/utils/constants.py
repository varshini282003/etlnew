
UNAUTHORIZED = "Invalid username or password"

PLAYER_NOT_FOUND = "No players found matching this search"

TEAM_NOT_FOUND = "No teams found matching this search"


MATCH_NOT_FOUND = "No matches found for provided filters"

JWT_EXPIRE_MINUTES = 60 