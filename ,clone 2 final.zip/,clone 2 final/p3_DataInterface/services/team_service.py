from typing import List
from neo4j import Driver
from common.logger_config import get_logger
from p3_DataInterface.schemas.team_schema import TeamResponse, TeamAttribute

logger = get_logger()

def get_teams_by_name(driver: Driver, name: str) -> List[TeamResponse]:

    cypher = """
    MATCH (t:Team)
    WHERE toLower(t.team_long_name) CONTAINS toLower($name)
    OPTIONAL MATCH (t)-[:TEAM_HAS_ATTRIBUTES]->(ta:TeamAttributes)
    RETURN 
        t.team_api_id AS team_api_id,
        t.team_long_name AS team_long_name,
        t.team_short_name AS team_short_name,
        collect({
            buildUpPlaySpeed: ta.buildUpPlaySpeed,
            buildUpPlayDribbling: ta.buildUpPlayDribbling,
            buildUpPlayPassing: ta.buildUpPlayPassing,
            chanceCreationPassing: ta.chanceCreationPassing,
            chanceCreationCrossing: ta.chanceCreationCrossing,
            chanceCreationShooting: ta.chanceCreationShooting,
            defencePressure: ta.defencePressure,
            defenceAggression: ta.defenceAggression,
            defenceTeamWidth: ta.defenceTeamWidth,
            date: ta.date
        }) AS attributes
    ORDER BY t.team_long_name
    """

    params = {"name": name}
    teams: List[TeamResponse] = []

    with driver.session() as session:  # type: ignore
        result = session.run(cypher, params)

        for record in result:
            raw_attrs = record["attributes"] or []

            cleaned_attrs = [
                TeamAttribute(**a)
                for a in raw_attrs
                if any(v is not None for v in a.values())
            ]

            teams.append(
                TeamResponse(
                    team_api_id=int(record["team_api_id"]),
                    team_long_name=record["team_long_name"],
                    team_short_name=record["team_short_name"],
                    attributes=sorted(
                        cleaned_attrs, key=lambda x: x.date or "", reverse=True
                    )
                )
            )

    logger.info(f"Team service → found {len(teams)} results for '{name}'")
    return teams
