from typing import List
from neo4j import Driver
from common.logger_config import get_logger
from p3_DataInterface.schemas.player_schema import PlayerResponse, PlayerAttribute

logger = get_logger()

def get_players_by_name(driver: Driver, name: str) -> List[PlayerResponse]:
  
    cypher = """
    MATCH (p:Player)
    WHERE toLower(p.player_name) CONTAINS toLower($name)
    OPTIONAL MATCH (p)-[:PLAYER_HAS_ATTRIBUTES]->(pa:PlayerAttributes)
    RETURN 
        p.player_api_id AS player_api_id,
        p.player_name AS player_name,
        p.height AS height,
        p.weight AS weight,
        collect({
            overall_rating: pa.overall_rating,
            potential: pa.potential,
            preferred_foot: pa.preferred_foot,
            attacking_work_rate: pa.attacking_work_rate,
            defensive_work_rate: pa.defensive_work_rate,
            date: pa.date
        }) AS attributes
    ORDER BY p.player_name
    """

    params = {"name": name}
    players: List[PlayerResponse] = []

    with driver.session() as session:  # type: ignore
        result = session.run(cypher, params)

        for record in result:
            raw_attrs = record["attributes"] or []

            cleaned_attrs = [
                PlayerAttribute(**a)
                for a in raw_attrs
                if any(v is not None for v in a.values())
            ]

            players.append(
                PlayerResponse(
                    player_api_id=int(record["player_api_id"]),
                    player_name=record["player_name"],
                    height=float(record["height"]) if record["height"] else None,
                    weight=float(record["weight"]) if record["weight"] else None,
                    attributes=sorted(
                        cleaned_attrs, key=lambda x: x.date or "", reverse=True
                    )
                )
            )

    logger.info(f"Player service → found {len(players)} results for '{name}'")
    return players
