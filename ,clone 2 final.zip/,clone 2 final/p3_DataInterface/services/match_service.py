from p2_DTL.neo4j_config import Neo4jConnection
from common.logger_config import get_logger

logger = get_logger()
conn = Neo4jConnection()

BASE_MATCH_RETURN = """
RETURN
    m.match_api_id AS match_api_id,
    m.date AS date,
    m.season AS season,
    m.stage AS stage,
    m.home_team_goal AS home_team_goal,
    m.away_team_goal AS away_team_goal,
    m.IWD AS IWD,
    m.IWA AS IWA,
    l.id AS league_id,
    l.name AS league_name,
    c.id AS country_id,
    c.name AS country_name,
    ht.team_long_name AS home_team_name,
    at.team_long_name AS away_team_name
ORDER BY m.date ASC
"""

def fetch_all_matches():
    cypher = f"""
        MATCH (m:Match)
        OPTIONAL MATCH (m)-[:MATCH_IN_LEAGUE]->(l:League)
        OPTIONAL MATCH (m)-[:MATCH_IN_COUNTRY]->(c:Country)
        OPTIONAL MATCH (m)-[:HOME_TEAM]->(ht:Team)
        OPTIONAL MATCH (m)-[:AWAY_TEAM]->(at:Team)
        {BASE_MATCH_RETURN}
        LIMIT 1000
    """

    with conn.get_driver().session() as s:
        result = s.run(cypher)
        return [rec.data() for rec in result]

def fetch_matches_by_team(team_name: str):

    cypher = f"""
        MATCH (m:Match)
        OPTIONAL MATCH (m)-[:MATCH_IN_LEAGUE]->(l:League)
        OPTIONAL MATCH (m)-[:MATCH_IN_COUNTRY]->(c:Country)
        OPTIONAL MATCH (m)-[:HOME_TEAM]->(ht:Team)
        OPTIONAL MATCH (m)-[:AWAY_TEAM]->(at:Team)
        WHERE toLower(ht.team_long_name) CONTAINS toLower($team)
           OR toLower(at.team_long_name) CONTAINS toLower($team)
        {BASE_MATCH_RETURN}
    """

    params = {"team": team_name}

    with conn.get_driver().session() as s:
        result = s.run(cypher, params)
        return [rec.data() for rec in result]
