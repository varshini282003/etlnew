from pydantic import BaseModel, Field
from typing import Optional, List


class TeamAttribute(BaseModel):
    buildUpPlaySpeed: Optional[int] = Field(None)
    buildUpPlayDribbling: Optional[int] = Field(None)
    buildUpPlayPassing: Optional[int] = Field(None)
    chanceCreationPassing: Optional[int] = Field(None)
    chanceCreationCrossing: Optional[int] = Field(None)
    chanceCreationShooting: Optional[int] = Field(None)
    defencePressure: Optional[int] = Field(None)
    defenceAggression: Optional[int] = Field(None)
    defenceTeamWidth: Optional[int] = Field(None)
    date: Optional[str] = Field(None)


class TeamResponse(BaseModel):
    team_api_id: int = Field(...)
    team_long_name: str = Field(...)
    team_short_name: Optional[str] = Field(None)

    # sorted in service
    attributes: List[TeamAttribute] = Field(default_factory=list)
