from pydantic import BaseModel, Field
from typing import Optional, List


class PlayerAttribute(BaseModel):
    overall_rating: Optional[int] = Field(None)
    potential: Optional[int] = Field(None)
    preferred_foot: Optional[str] = Field(None)
    attacking_work_rate: Optional[str] = Field(None)
    defensive_work_rate: Optional[str] = Field(None)
    date: Optional[str] = Field(None)


class PlayerResponse(BaseModel):
    player_api_id: int = Field(..., description="Unique ID of the player")
    player_name: str = Field(..., description="Player name")
    height: Optional[float] = Field(None)
    weight: Optional[float] = Field(None)

    # sorted in service layer
    attributes: List[PlayerAttribute] = Field(default_factory=list)
