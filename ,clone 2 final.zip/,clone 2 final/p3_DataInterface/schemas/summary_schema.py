from pydantic import BaseModel, Field


class SummaryResponse(BaseModel):
    league_id: int = Field(...)
    league_name: str = Field(...)
    country_id: int = Field(...)
    country_name: str = Field(...)
    match_count: int = Field(...)
