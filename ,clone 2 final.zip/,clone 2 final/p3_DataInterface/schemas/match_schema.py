from pydantic import BaseModel, Field
from typing import Optional

class MatchResponse(BaseModel):
    match_api_id: int = Field(..., description="Unique ID of the match")
    date: Optional[str]
    season: Optional[str]
    stage: Optional[int]
    home_team_goal: Optional[int]
    away_team_goal: Optional[int]
    IWD: Optional[float]
    IWA: Optional[float]

    league_id: Optional[int]
    league_name: Optional[str]

    country_id: Optional[int]
    country_name: Optional[str]

    home_team_name: Optional[str]
    away_team_name: Optional[str]

    class Config:
        schema_extra = {
            "example": {
                "match_api_id": 12345,
                "date": "2015-09-20",
                "season": "2015/2016",
                "stage": 5,
                "home_team_goal": 3,
                "away_team_goal": 1,
                "IWD": 0.35,
                "IWA": 0.25,
                "league_id": 1729,
                "league_name": "Premier League",
                "country_id": 1,
                "country_name": "England",
                "home_team_name": "Manchester United",
                "away_team_name": "Chelsea"
            }
        }
