import os
import sqlite3
import pandas as pd
from common.logger_config import setup_logger  

class SQLiteExtractor: #Single Responsibility SOLID principles

    def __init__(self, db_path, output_dir="data"):
        base_dir = os.path.abspath(os.path.dirname(__file__))

        if not os.path.isabs(db_path):
            db_path = os.path.normpath(os.path.join(base_dir, "..", db_path))
        self.db_path = db_path

        self.output_dir = os.path.normpath(os.path.join(base_dir, "..", output_dir))
        os.makedirs(self.output_dir, exist_ok=True)

        self.logger = setup_logger(log_dir=os.path.normpath(os.path.join(base_dir, "..", "logs"))) 

        self.conn = None

    def connect(self):
        
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.logger.info(f" Connected to database: {self.db_path}")
        except Exception as e:
            self.logger.error(f" Failed to connect to database: {e}")
            raise 

    def get_table_names(self):
        
        try:
            cursor = self.conn.cursor() # type: ignore
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';") #retrieves all table names dynamically
            tables = [t[0] for t in cursor.fetchall()]
            self.logger.info(f" Found {len(tables)} tables: {tables}")
            return tables
        except Exception as e:
            self.logger.error(f"Error fetching table names: {e}")
            return []

    def extract_table(self, table_name):
        try:
            query = f'SELECT * FROM "{table_name}"'
            df = pd.read_sql_query(query, self.conn) # type: ignore

            if df.empty:
                self.logger.warning(f"Table '{table_name}' is empty. Skipping.")
                return

            output_path = os.path.join(self.output_dir, f"{table_name}.csv")
            df.to_csv(output_path, index=False, encoding="utf-8")
            self.logger.info(f" Extracted table '{table_name}' → {output_path}")
            #df.to_parquet(os.path.join(self.output_dir, f"{table_name}.parquet"), index=False)
        except Exception as e:
            self.logger.error(f"Error extracting '{table_name}': {e}")

    def extract_all_tables(self):
        
        tables = self.get_table_names()
        for table in tables:
            self.extract_table(table)

    def run(self):
       
        try:
            self.connect()
            self.extract_all_tables()
            self.logger.info(" Extraction completed successfully.")
        except Exception as e:
            self.logger.error(f" Extraction failed: {e}")
        finally:
            if self.conn:
                self.conn.close()
                self.logger.info(" Database connection closed.")

if __name__ == "__main__":
    db_path = os.path.join("database", "database.sqlite")
    extractor = SQLiteExtractor(db_path)
    extractor.run()
